import random

questions = {
        "Houston, we have a problem." : "Apollo 13",
        "I'll be back." : "Terminator",
        "Remember who you are." : "The Lion King",
        "I'm the king of the world!" : "Titanic",
        "There's no place like home." : "The Wizard of Oz",
        "To infinity and beyond!" : "Toy Story",
        "Inconceivable!" : "The Princess Bride",
        "As if!" : "Clueless",
        "Here's Johnny!" : "The Shining",
        "It was beauty killed the beast." : "King Kong"
        }

while(1):
    try:
        num=int(input("How many questions would you like?"))
        break
    except:
        pass

rset = random.sample(list(questions),num)
correct_num=0
for ind,Q in enumerate(rset):
    print(f"Question #{ind+1}: From what movie is the following quote?\n\n{Q}\n")
    ans=input("Your Answer:")
   
    if(ans.lower()==questions[Q].lower()):
        correct_num+=1
        print("Correct!")
    else:
        print(f"Incorrect! The correct answer is: {questions[Q]}")

print(f"You answered {correct_num} out of {num} questions correctly.")